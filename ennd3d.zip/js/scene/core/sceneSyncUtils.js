// js/scene/core/sceneSyncUtils.js
import { getActiveViewer, isSyncMode } from '../../ui/viewerSwitch.js';
import { getSceneById, getCameraById, getRendererById, getModelById } from './viewerRegistry.js';

// js/scene/core/sceneSyncUtils.js (continuación)

export function applyToRelevantViewers(callback) {
  const apply = (viewerId) => {
    const context = {
      viewerId,
      scene: getSceneById(viewerId),
      camera: getCameraById(viewerId),
      renderer: getRendererById(viewerId),
      model: getModelById(viewerId),
    };
    if (context.scene) callback(context);
  };

  if (isSyncMode()) {
    apply('indexViewer1'); // o 'viewer1' según tu caso
    apply('viewer2');
  } else {
    apply(`viewer${getActiveViewer()}`);
  }
}
